def vectorize_dic(dic, ix=None, p=None, n=0, g=0):
    if ix == None:
        ix = dict()
    nz = n * g
    col_ix = np.empty(nz, dtype=int)  # 每行起始的偏移量
    i = 0
    for k, lis in dic.items():  # 遍历文档
        for t in range(len(lis)):  # 遍历每个词
            ix[str(lis[t]) + str(k)] = ix.get(str(lis[t]) + str(k), 0) + 1
            col_ix[i+t*g] = ix[str(lis[t]) + str(k)]
        i += 1

    row_ix = np.repeat(np.arange(0, n), g)  # 每个数对应的列号
    data = np.ones(nz)
    if p == None:
        p = len(ix)

    ixx = np.where(col_ix < p)  # 输出满足条件的值
    return csr.csr_matrix((data[ixx], (row_ix[ixx], col_ix[ixx])), shape=(n, p)), ix

# batch函数


def batcher(X_, y_=None, batch_size=-1):
    n_samples = X_.shape[0]

    if batch_size == -1:
        batch_size = n_samples
    if batch_size < 1:
        raise ValueError(
            'Parameter batch_size={} is unsupported'.format(batch_size))

    for i in range(0, n_samples, batch_size):
        upper_bound = min(i + batch_size, n_samples)
        ret_x = X_[i:upper_bound]
        ret_y = None
        if y_ is not None:
            ret_y = y_[i:i + batch_size]
            yield (ret_x, ret_y)


# 读入数据
cols = ['user', 'item', 'rating', 'timestamp']
train = pd.read_csv('ml-100k/ua.base', delimiter='\t', names=cols)
test = pd.read_csv('ml-100k/ua.test', delimiter='\t', names=cols)

# print(train, test)
x_train, ix = vectorize_dic({'users': train['user'].values,
                             'items': train['item'].values}, n=len(train.index), g=2)

x_test, ix = vectorize_dic({'users': test['user'].values,
                            'items': test['item'].values}, ix, x_train.shape[1], n=len(test.index), g=2)

print(ix)


