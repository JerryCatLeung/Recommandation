from itertools import count
from collections import defaultdict
from scipy.sparse import csr_matrix
import numpy as np
import pandas as pd
import tensorflow as tf
import pickle

cols = ['user', 'item', 'rating', 'timestamp']

train = pd.read_csv('ml-100k/ua.base', delimiter='\t', names=cols)
test = pd.read_csv('ml-100k/ua.test', delimiter='\t', names=cols)
train = train.drop(['timestamp'], axis=1)
test = test.drop(['timestamp'], axis=1)


# DictVectorizer会把数字识别为连续特征，这里把用户id和item id强制转为 catogorical identifier
train["item"] = train["item"].apply(lambda x: str(x) + "c")
train["user"] = train["user"].apply(lambda x: str(x) + "u")

test["item"] = test["item"].apply(lambda x: str(x) + "c")
test["user"] = test["user"].apply(lambda x: str(x) + "u")

all_df = pd.concat([train, test])

userid_list = all_df["user"].unique()
itemid_list = all_df["item"].unique()

# user数量
num_userid = len(userid_list)
# item数量
num_itemid = len(itemid_list)
print(num_userid, num_itemid)

# uerid转换为数字
userid2int = {}
# itemid转换为数字
itemid2int = {}

height = all_df.shape[0]
width = num_userid + num_itemid

for index, vlaue in enumerate(userid_list):
    userid2int[vlaue] = index
for index, vlaue in enumerate(itemid_list):
    itemid2int[vlaue] = index

indices = []
for index, value in all_df.iterrows():
    userid = value["user"]
    itemid = value["item"]
    userid_index = userid2int.get(userid)
    itemid_index = itemid2int.get(itemid)
    indices.append(userid_index)
    indices.append(num_userid + itemid_index)

indptr = []
for i in range(height+1):
    indptr.append(i*2)

indptr = np.array(indptr)
indices = np.array(indices)
data = np.array([1] * height * 2)
a = csr_matrix((data, indices, indptr), shape=(height, width))

x_train = a.toarray()
print(x_train.shape)

y_train = all_df['rating'].values.reshape(-1, 1)
print(y_train.shape)

n, p = x_train.shape

# latent vector
k = 10

x = tf.placeholder('float', [None, p])
y = tf.placeholder('float', [None, 1])

w0 = tf.Variable(tf.zeros([1]))
# [p]
w = tf.Variable(initial_value=tf.random_normal(shape=[p], mean=0, stddev=0.1))
# [k, p]
v = tf.Variable(tf.random_normal([k, p], mean=0, stddev=0.01))

linear_terms = tf.add(w0, tf.reduce_sum(
    tf.multiply(w, x), 1, keep_dims=True))

pair_interactions = 0.5 * tf.reduce_sum(
    tf.subtract(
        tf.pow(tf.matmul(x, tf.transpose(v)), 2),
        tf.matmul(
            tf.pow(x, 2),
            tf.transpose(tf.pow(v, 2))
        )
    ),
    axis=1,
    keep_dims=True)


y_hat = tf.add(linear_terms, pair_interactions)
lambda_w = tf.constant(0.001, name='lambda_w')
lambda_v = tf.constant(0.001, name='lambda_v')

#  加l2 正则，提高解的泛化能力
l2_norm = 0.5*tf.reduce_sum(
    tf.add(
        tf.multiply(lambda_w, tf.pow(w, 2)),
        tf.multiply(lambda_v, tf.pow(v, 2))
    )
)

error = tf.reduce_mean(tf.square(y-y_hat))
loss = tf.add(error, l2_norm)


train_op = tf.train.GradientDescentOptimizer(learning_rate=0.02).minimize(loss)

epochs = 1

# Launch the graph
init = tf.global_variables_initializer()
with tf.Session() as sess:
    sess.run(init)

    for epoch in range(epochs):
        # iterate over batches
        _, t = sess.run([train_op, loss], feed_dict={
                        x: x_train, y: y_train})
        validate_loss = sess.run(error, feed_dict={x: x_train, y: y_train})
        print("epoch:%d train loss:%f validate_loss:%s" %
              (epoch, t, validate_loss))
    
    variable_names = [v.name for v in tf.trainable_variables()]
    print(variable_names)

    graph = tf.get_default_graph()

    print("Variable_2:0")
    print("##########################################")
    x1 = graph.get_tensor_by_name("Variable_2:0")
    print("the shape of user_matrix is ", x1)
    tmp_x1 = sess.run(x1)
print(tmp_x1.T)

# # user vector列表
# group_user_df = all_df.groupby("user")
# user_vector_list = {}
# for user in group_user_df:
#     tmp_matrix = []
#     userid = user[0]
#     user_data_df = user[1]
#     user_group_height = user_data_df.shape[0]
#     item_list = list(user_data_df["item"].unique())
#     # 获取userid_index
#     userid_index = userid2int.get(userid)
    
#     user_indptr = []
#     for i in range(user_group_height+1):
#         user_indptr.append(i*2)
    
#     user_indices = []
#     for itemid in item_list:
#         # 获取itemid_index
#         itemid_index = itemid2int.get(itemid)
#         user_indices.append(userid_index)
#         user_indices.append(num_userid + itemid_index)
    
#     user_data = np.array([1] * user_group_height * 2)
#     user_martix = csr_matrix((user_data, user_indices, user_indptr), shape=(user_group_height, width))
#     user_vector = np.dot(user_martix, csr_matrix(tmp_x1.T)).sum(axis=0)
#     user_vector_list[userid] = user_vector

