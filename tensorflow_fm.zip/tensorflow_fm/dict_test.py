# coding=utf-8
from itertools import count
from collections import defaultdict
from scipy.sparse import csr
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.feature_extraction import DictVectorizer
import pickle

cols = ['user', 'item', 'rating', 'timestamp']

train = pd.read_csv('ml-100k/ua.base', delimiter='\t', names=cols)
test = pd.read_csv('ml-100k/ua.test', delimiter='\t', names=cols)
train = train.drop(['timestamp'], axis=1)
test = test.drop(['timestamp'], axis=1)


# DictVectorizer会把数字识别为连续特征，这里把用户id和item id强制转为 catogorical identifier
train["item"] = train["item"].apply(lambda x: str(x) + "c")
train["user"] = train["user"].apply(lambda x: str(x) + "u")

test["item"] = test["item"].apply(lambda x: str(x) + "c")
test["user"] = test["user"].apply(lambda x: str(x) + "u")

all_df = pd.concat([train, test])

userid_list = all_df["user"].unique()
itemid_list = all_df["item"].unique()

# user数量
num_userid = len(userid_list)
# item数量
num_itemid = len(itemid_list)
print(num_userid, num_itemid)

# uerid转换为数字
userid2int = {}
# itemid转换为数字
itemid2int = {}


for index, vlaue in enumerate(userid_list):
    userid2int[vlaue] = index
for index, vlaue in enumerate(itemid_list):
    itemid2int[vlaue] = index

f1 = open("./useridonehot.pkl", "wb")
f2 = open("./itemidonehot.pkl", "wb")

userid2onehot = {}
itemid2onehot = {}

for userid in userid2int:
    userid_index = userid2int.get(userid, 0)
    zeros_list = np.zeros(num_userid)
    zeros_list[userid_index] = 1
    userid2onehot[userid] = zeros_list

for itemid in itemid2int:
    itemid_index = itemid2int.get(itemid, 0)
    zeros_list = np.zeros(num_itemid)
    zeros_list[itemid_index] = 1
    itemid2onehot[itemid] = zeros_list


pickle.dump(userid2onehot, f1, protocol=pickle.HIGHEST_PROTOCOL)
pickle.dump(itemid2onehot, f2, protocol=pickle.HIGHEST_PROTOCOL)

f1.close()
f2.close()

x_train_matrix = []
for index, value in all_df.iterrows():
    userid = value["user"]
    itemid = value["item"]
    tmp_onehot = list(userid2onehot.get(userid)) + list(itemid2onehot.get(itemid))
    x_train_matrix.append(tmp_onehot)

x_train = np.array(x_train_matrix)
print(x_train.shape)

y_train = all_df['rating'].values.reshape(-1, 1)
print(y_train.shape)

n, p = x_train.shape

# latent vector
k = 40

x = tf.placeholder('float', [None, p])
y = tf.placeholder('float', [None, 1])

w0 = tf.Variable(tf.zeros([1]))
# [p]
w = tf.Variable(initial_value=tf.random_normal(shape=[p], mean=0, stddev=0.1))
# [k, p]
v = tf.Variable(tf.random_normal([k, p], mean=0, stddev=0.01))

linear_terms = tf.add(w0, tf.reduce_sum(
    tf.multiply(w, x), 1, keep_dims=True))

pair_interactions = 0.5 * tf.reduce_sum(
    tf.subtract(
        tf.pow(tf.matmul(x, tf.transpose(v)), 2),
        tf.matmul(
            tf.pow(x, 2),
            tf.transpose(tf.pow(v, 2))
        )
    ),
    axis=1,
    keep_dims=True)


y_hat = tf.add(linear_terms, pair_interactions)
lambda_w = tf.constant(0.001, name='lambda_w')
lambda_v = tf.constant(0.001, name='lambda_v')

#  加l2 正则，提高解的泛化能力
l2_norm = 0.5*tf.reduce_sum(
    tf.add(
        tf.multiply(lambda_w, tf.pow(w, 2)),
        tf.multiply(lambda_v, tf.pow(v, 2))
    )
)

error = tf.reduce_mean(tf.square(y-y_hat))
loss = tf.add(error, l2_norm)


train_op = tf.train.GradientDescentOptimizer(learning_rate=0.02).minimize(loss)

epochs = 1

# Launch the graph
init = tf.global_variables_initializer()
with tf.Session() as sess:
    sess.run(init)

    for epoch in range(epochs):
        # iterate over batches
        _, t = sess.run([train_op, loss], feed_dict={
                        x: x_train, y: y_train})
        validate_loss = sess.run(error, feed_dict={x: x_train, y: y_train})
        print("epoch:%d train loss:%f validate_loss:%s" %
              (epoch, t, validate_loss))
    
    variable_names = [v.name for v in tf.trainable_variables()]
    print(variable_names)

    graph = tf.get_default_graph()

    print("Variable:0")
    print("##########################################")
    x1 = graph.get_tensor_by_name("Variable:0")
    print("the shape of user_matrix is ", x1)
    tmp_x1 = sess.run(x1)
    print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
    print("the type of tmp_x1 is :")
    print(type(tmp_x1))
    print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
    print(tmp_x1.shape)
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    for user_per in tmp_x1:
        print(user_per)
    
    print("Variable_1:0")
    print("##########################################")
    x1 = graph.get_tensor_by_name("Variable_1:0")
    print("the shape of user_matrix is ", x1)
    tmp_x1 = sess.run(x1)
    print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
    print("the type of tmp_x1 is :")
    print(type(tmp_x1))
    print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
    print(tmp_x1.shape)
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    for user_per in tmp_x1:
        print(user_per)

    print("Variable_2:0")
    print("##########################################")
    x1 = graph.get_tensor_by_name("Variable_2:0")
    print("the shape of user_matrix is ", x1)
    tmp_x1 = sess.run(x1)
    print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
    print("the type of tmp_x1 is :")
    print(type(tmp_x1))
    print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
    print(tmp_x1.shape)
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    print(tmp_x1.T)
    print("******************************************")
    print(tmp_x1.T.shape)
    for user_per in tmp_x1:
        print(user_per)
print("&###########&&&&&&")   
print(tmp_x1.T)

# user vector列表
group_user_df = all_df.groupby("user")
user_vector_list = {}
for user in group_user_df:
    tmp_matrix = []
    userid = user[0]
    user_data_df = user[1]
    item_list = list(user_data_df["item"].unique())
    user_onehot = list(userid2onehot.get(userid))
    for item in item_list:
        item_onehot = list(itemid2onehot.get(item))
        tmp_matrix.append(user_onehot + item_onehot)
    tmp_matrix = np.mat(tmp_matrix)
    user_vector = np.dot(tmp_matrix, np.mat(tmp_x1.T)).sum(axis=0)
    user_vector_list[userid] = list(np.array(user_vector)[0])

# item vector列表
group_item_df = all_df.groupby("item")
item_vector_list = {}
for item in group_item_df:
    tmp_matrix = []
    itemid = item[0]
    item_data_df = item[1]
    user_list = list(item_data_df["user"].unique())
    item_onehot = list(itemid2onehot.get(itemid))
    for user in user_list:
        user_onehot = list(userid2onehot.get(user))
        tmp_matrix.append(user_onehot + item_onehot)
    tmp_matrix = np.mat(tmp_matrix)
    item_vector = np.dot(tmp_matrix, np.mat(tmp_x1.T)).sum(axis=0)
    item_vector_list[itemid] = list(np.array(item_vector)[0])

f1 = open("./uservector.pkl", "wb")
f2 = open("./itemvector.pkl", "wb")

pickle.dump(user_vector_list, f1)
pickle.dump(item_vector_list, f2)

print("finished")